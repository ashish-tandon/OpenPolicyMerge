#!/usr/bin/env bash
set -euo pipefail

NAMESPACE=${NAMESPACE:-openpolicy-dev}
API_SVC=api-gateway
WEB_SVC=web

echo "Running dev smoke tests against namespace: $NAMESPACE"

# Port-forward API and WEB locally for smoke tests
kubectl -n "$NAMESPACE" port-forward svc/$API_SVC 18080:80 >/tmp/api_pf.log 2>&1 &
API_PID=$!
kubectl -n "$NAMESPACE" port-forward svc/$WEB_SVC 13000:80 >/tmp/web_pf.log 2>&1 &
WEB_PID=$!

cleanup() { kill $API_PID $WEB_PID || true; }
trap cleanup EXIT

sleep 3

curl -fsS http://localhost:18080/healthz >/dev/null
curl -fsS http://localhost:18080/version >/dev/null
curl -fsS "http://localhost:18080/bills?page=1" >/dev/null || true

curl -fsS http://localhost:13000/ >/dev/null

echo "Smoke tests passed."

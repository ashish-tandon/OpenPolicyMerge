# ADR-XXXX: <Decision Title>

- Status: Proposed | Accepted | Superseded
- Context:
- Decision:
- Consequences:
- Alternatives considered:
- Date:

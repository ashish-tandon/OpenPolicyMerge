# Architecture Implementation Status

- Discovery wired: [ ] dev  [ ] staging  [ ] prod
- API spec-first enforced: [ ]
- Alembic baseline + pipeline: [ ]
- Contract tests running in CI: [ ]
- ETL idempotent loaders: [ ]
- UI feature-flagged to new API: [ ]
- Pre-PR gate green: [ ]
- Deployment doc completed: [ ]
